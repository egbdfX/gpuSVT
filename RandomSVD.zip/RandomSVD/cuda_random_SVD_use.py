from cuRandomSVD import *

A_nRows = 5;
A_nCols = 5;
nIterations = 2;
rank = 2;
p = 2;
U_nCols = A_nRows; # >= max(1,A_nRows)
V_nRows = A_nCols; # >= max(1,A_nCols)
S_nCols = min(A_nRows,A_nCols) # This could be rank


#here it should be really (need to try that)
#U_size_bytes = A_nRows*rank;
#V_size_bytes = rank*V_nCols;
#S_size_bytes = S_nCols;

A_size_bytes = A_nRows*A_nCols;
U_size_bytes = A_nRows*U_nCols;
V_size_bytes = V_nRows*A_nCols;
S_size_bytes = S_nCols;

matrix_A = np.array([ [0.76420743, 0.61411544, 0.81724151, 0.42040879, 0.03446089] , [0.03697287, 0.85962444, 0.67584086, 0.45594666, 0.02074835] , [0.42018265, 0.39204509, 0.12657948, 0.90250559, 0.23076218] , [0.50339844, 0.92974961, 0.21213988, 0.63962457, 0.58124562] , [0.58325673, 0.11589871, 0.39831112, 0.21492685, 0.00540355] ], dtype=np.float64, order='F')

matrix_U = np.zeros((A_nRows, U_nCols), dtype=np.float64, order='F');
matrix_V = np.zeros((V_nRows, A_nCols), dtype=np.float64, order='F');
matrix_S = np.zeros(S_nCols, dtype=np.float64, order='F');

print(matrix_A.ndim)
print(matrix_A.shape)

print(matrix_A)

print(matrix_S)
print("----------------------------------------------")

S, U, V = cuRandomSVD(matrix_A, rank, p, nIterations);

print('S:',S)
print('U:',U)
print('V:',V)
